import numpy as np
import matplotlib.pylab as plt
import tensorflow as tf
from tensorflow import keras as ks
import input_data
import shutil
import tensorflow_hub as hub
from tensorflow.keras.utils import to_categorical
print("\u2022 Using TensorFlow Version:",tf.__version__)
print("\u2022 Using TensorFlow Hub Version:",hub.__version__)
print("\u2022 GPU is","available:"if tf.config.list_physical_devices('GPU') else "NOT AVAILABLE")

#加载tensorflow-hub模型的参数
module_selection = ("mobilenet_v2",224,1280)
handle_base,pixels,FV_SIZE = module_selection
# MODULE_HANDLE = "https://tfhub.dev/google/imagenet/mobilenet_v2_100_224/feature_vector/4"
MODULE_HANDLE = "./5/"
IMAGE_SIZE = (pixels,pixels)

#数据加载，划分数据集
dataset_dir = "./SessionAllLayers"
network_mnist = input_data.read_data_sets(dataset_dir)

train_examples = network_mnist.train.images
train_labels = network_mnist.train.labels

validation_examples = network_mnist.validation.images
validation_labels = network_mnist.validation.labels

test_examples = network_mnist.test.images
test_labels = network_mnist.test.labels

#数据加载-图像三通道转换
def image_transform(images,size=(28,28)):
    new_images = []
    for image in images:
        arr_result = []
        for i in image:
            arr_sum = []
            arr_sum.append(i)
            arr_sum.append(i) 
            arr_sum.append(i) 
            arr_result.append(arr_sum)
        new_images.append(np.reshape(arr_result,size + (3,)))
    return np.array(new_images)

train_examples = image_transform(train_examples,size=(28,28))
validation_examples = image_transform(validation_examples,size=(28,28))
test_examples = image_transform(test_examples,size=(28,28))
train_labels = to_categorical(train_labels)
validation_labels = to_categorical(validation_labels)
test_labels = to_categorical(test_labels)

#加载mobilenet_v2模型
do_fine_tuning = False
num_class = 2

feature_extractor = hub.KerasLayer(MODULE_HANDLE,
                                    input_shape=IMAGE_SIZE+(3,),
                                    output_shape=[FV_SIZE],
                                    trainable=do_fine_tuning)
                                    
#根据需要可选择是否重构mobilenet_v2模型的参数
NUM_LAYERS = 10

if do_fine_tuning:
    feature_extractor.trainable = True
    for layer in model.layers[-NUM_LAYERS:]:
        layer.trainable = True
else:
    feature_extractor.trainable = False

#构建模型
model = tf.keras.Sequential([
    tf.keras.layers.ZeroPadding2D(padding=98),
    feature_extractor,
    tf.keras.layers.Dense(32,activation='relu'),
    tf.keras.layers.Dense(num_class,activation='sigmoid')
])
model.build((None,) + (28,28) +(3,))

model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=0.0003,momentum=0.9),
                  loss=tf.keras.losses.categorical_crossentropy,
                 metrics=['accuracy'])
                 
#训练模型
EPOCHS = 2
hist = model.fit(train_examples,
                 train_labels,
                epochs=EPOCHS,
                verbose=1,
                batch_size=48,
                validation_data=(validation_examples,validation_labels))

#画折线图
acc = hist.history['accuracy']
val_acc = hist.history['val_accuracy']
loss = hist.history['loss']
val_loss = hist.history['val_loss']

epochs = range(len(acc))
plt.plot(epochs,acc,'r','Training Accuracy')
plt.plot(epochs,val_acc,'b','Validation Accuracy')
plt.title('Training and Validation accuracy')
plt.savefig('./tf1.png')
plt.figure()

plt.plot(epochs,loss,'r','Training Loss')
plt.plot(epochs,val_loss,'b','Validation Loss')
plt.title('Training and Validation loss')
plt.savefig('./tf2.png')

#testing model
test_hist = model.evaluate(test_examples,test_labels,return_dict=True)
print(f"The Accuracy rate of this model on the test set is {test_hist['accuracy']} and the loss rate is {test_hist['loss']}")

#MobileNet层与预处理层中间结果图
layer_outputs = [layer.output for layer in model.layers]
activation_model = ks.models.Model(inputs=model.input,outputs=layer_outputs)
prid = activation_model.predict(test_examples[0:9])

fig1 = plt.figure(num=1,figsize=(7,7),facecolor='white')
axes1 = fig1.subplots(3,3)
axes1[0][0].imshow(np.reshape(prid[1][0,:],(32,40)))
axes1[0][1].imshow(np.reshape(prid[1][1,:],(32,40)))
axes1[0][2].imshow(np.reshape(prid[1][2,:],(32,40)))
axes1[1][0].imshow(np.reshape(prid[1][3,:],(32,40)))
axes1[1][1].imshow(np.reshape(prid[1][4,:],(32,40)))
axes1[1][2].imshow(np.reshape(prid[1][5,:],(32,40)))
axes1[2][0].imshow(np.reshape(prid[1][6,:],(32,40)))
axes1[2][1].imshow(np.reshape(prid[1][7,:],(32,40)))
axes1[2][2].imshow(np.reshape(prid[1][8,:],(32,40)))
plt.savefig("./Mobile-Net.png")

fig2 = plt.figure(num=2,figsize=(7,7),facecolor='white')
axes2 = fig2.subplots(3,3)
axes2[0][0].imshow(prid[0][0,98:127,98:127,0])
axes2[0][1].imshow(prid[0][1,98:127,98:127,0])
axes2[0][2].imshow(prid[0][2,98:127,98:127,0])
axes2[1][0].imshow(prid[0][3,98:127,98:127,0])
axes2[1][1].imshow(prid[0][4,98:127,98:127,0])
axes2[1][2].imshow(prid[0][5,98:127,98:127,0])
axes2[2][0].imshow(prid[0][6,98:127,98:127,0])
axes2[2][1].imshow(prid[0][7,98:127,98:127,0])
axes2[2][2].imshow(prid[0][8,98:127,98:127,0])
plt.savefig("./padding.png")
#保存模型
EXPORT_DIR = './anomaly_detection'
tf.saved_model.save(model,export_dir=EXPORT_DIR)
